# LiteTV

Reproductor de listas M3U para Android TV, pensado para equipos de 1 GB de RAM.

## Cómo compilar el APK (GitHub Actions)

1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (incluida `.github`).
2. Entra en la pestaña **Actions** y espera a que termine "Compilar APK".
3. Descarga el artefacto **LiteTV-apk**: dentro está `app-release.apk`.
4. Instálalo en la TV (USB, "Send Files to TV" o `adb install app-release.apk`).

## Uso

- OK / Enter: abre la lista de canales. Arriba/Abajo (con la lista cerrada): cambia de canal.
- Menú, o el botón "Ajustes y lista": pega la URL de tu lista M3U y cambia el User-Agent.
- Atrás: cierra la lista.

## Motor de reproducción (app/src/main/java/com/litetv/app/PlayerEngine.kt)

- Buffers: 15 s mínimo, 40 s máximo, 2,5 s para arrancar, 5 s tras un corte (tope de 24 MB).
- Decodificador por hardware con respaldo automático a software.
- MPEG-TS directo, HLS, redirecciones http/https.
- Reintentos con espera creciente (1, 2, 4, 8, 10 s) y vigilante anti-congelamiento.

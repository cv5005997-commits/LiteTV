# Media3 ya trae sus propias reglas para R8 (consumer rules).
# No hace falta nada extra para esta app.

package com.litetv.app

data class Channel(val name: String, val group: String, val url: String)

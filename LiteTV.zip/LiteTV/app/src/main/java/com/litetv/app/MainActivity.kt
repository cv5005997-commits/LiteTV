package com.litetv.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var surface: SurfaceView
    private lateinit var panel: View
    private lateinit var list: ListView
    private lateinit var status: TextView

    private var engine: PlayerEngine? = null
    private var channels: List<Channel> = emptyList()
    private var current: Channel? = null

    private val ui = Handler(Looper.getMainLooper())
    private val hideStatus = Runnable { status.visibility = View.GONE }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = channels.size
        override fun getItem(position: Int): Any = channels[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView
                ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
            val c = channels[position]
            row.findViewById<TextView>(android.R.id.text1).apply {
                text = c.name
                textSize = 20f
            }
            row.findViewById<TextView>(android.R.id.text2).apply {
                text = c.group
                textSize = 14f
            }
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = Prefs(this)
        surface = findViewById(R.id.surface)
        panel = findViewById(R.id.panel)
        list = findViewById(R.id.list)
        status = findViewById(R.id.status)

        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            playChannel(channels[pos])
            hidePanel()
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }

        if (prefs.playlistUrl.isBlank() && !cacheFile().exists()) {
            showPanel()
            ui.post { showSettings() }
        }
        loadPlaylist()
    }

    override fun onStart() {
        super.onStart()
        createEngine()
        current?.let { engine?.play(it) }
    }

    override fun onStop() {
        super.onStop()
        // Liberar el reproductor al salir: en 1 GB de RAM cada MB cuenta
        engine?.release()
        engine = null
    }

    // ---------- Reproducción ----------

    private fun createEngine() {
        engine = PlayerEngine(this, prefs.userAgent) { msg -> onEngineStatus(msg) }
            .also { it.attach(surface) }
    }

    private fun playChannel(ch: Channel) {
        current = ch
        prefs.lastUrl = ch.url
        showStatus(ch.name, persistent = false)
        engine?.play(ch)
        val idx = channels.indexOf(ch)
        if (idx >= 0) list.setSelection(idx)
    }

    private fun zap(delta: Int) {
        if (channels.isEmpty()) return
        val idx = channels.indexOf(current).let { if (it < 0) 0 else it }
        playChannel(channels[(idx + delta + channels.size) % channels.size])
    }

    private fun onEngineStatus(msg: String?) {
        if (msg != null) {
            showStatus(msg, persistent = true)
        } else {
            ui.removeCallbacks(hideStatus)
            ui.postDelayed(hideStatus, 2500)
        }
    }

    private fun showStatus(text: String, persistent: Boolean) {
        status.text = text
        status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        if (!persistent) ui.postDelayed(hideStatus, 4000)
    }

    // ---------- Lista de canales ----------

    private fun cacheFile() = File(filesDir, "playlist.m3u")

    private fun loadPlaylist() {
        val url = prefs.playlistUrl
        val ua = prefs.userAgent
        val cache = cacheFile()
        Thread {
            // 1) Mostrar al instante la última lista guardada
            if (cache.exists()) {
                runCatching { PlaylistLoader.parse(cache) }
                    .onSuccess { l -> runOnUiThread { setChannels(l) } }
            }
            // 2) Actualizarla desde internet sin interrumpir lo que se está viendo
            if (url.isNotBlank()) {
                try {
                    PlaylistLoader.download(url, ua, cache)
                    val l = PlaylistLoader.parse(cache)
                    runOnUiThread { setChannels(l) }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, "No se pudo actualizar la lista: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }.start()
    }

    private fun setChannels(newList: List<Channel>) {
        channels = newList
        adapter.notifyDataSetChanged()
        if (newList.isEmpty()) {
            showStatus("La lista no tiene canales", persistent = false)
            return
        }
        if (current == null) {
            val last = prefs.lastUrl
            playChannel(newList.firstOrNull { it.url == last } ?: newList[0])
        } else {
            val idx = newList.indexOf(current)
            if (idx >= 0) list.setSelection(idx)
        }
    }

    // ---------- Panel y teclas del control remoto ----------

    private fun showPanel() {
        panel.visibility = View.VISIBLE
        list.requestFocus()
        val idx = channels.indexOf(current)
        if (idx >= 0) list.setSelection(idx)
    }

    private fun hidePanel() {
        panel.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (panel.visibility != View.VISIBLE) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MENU -> {
                    showPanel(); return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                    zap(-1); return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                    zap(1); return true
                }
            }
        } else {
            when (keyCode) {
                KeyEvent.KEYCODE_BACK -> { hidePanel(); return true }
                KeyEvent.KEYCODE_MENU -> { showSettings(); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Ajustes ----------

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val urlInput = EditText(this).apply {
            hint = "URL de la lista M3U (http o https)"
            setText(prefs.playlistUrl)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val uaInput = EditText(this).apply {
            hint = "User-Agent"
            setText(prefs.userAgent)
            setSingleLine()
        }
        box.addView(urlInput)
        box.addView(uaInput)

        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.playlistUrl = urlInput.text.toString().trim()
                prefs.userAgent = uaInput.text.toString().trim().ifEmpty { Prefs.DEFAULT_UA }
                // Reiniciar el motor para aplicar el nuevo User-Agent
                engine?.release()
                createEngine()
                current?.let { engine?.play(it) }
                loadPlaylist()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}

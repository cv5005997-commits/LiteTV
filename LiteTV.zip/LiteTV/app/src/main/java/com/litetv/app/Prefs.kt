package com.litetv.app

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("litetv", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = sp.getString("playlist_url", "") ?: ""
        set(v) = sp.edit().putString("playlist_url", v).apply()

    var userAgent: String
        get() = sp.getString("user_agent", DEFAULT_UA)?.ifBlank { DEFAULT_UA } ?: DEFAULT_UA
        set(v) = sp.edit().putString("user_agent", v).apply()

    var lastUrl: String
        get() = sp.getString("last_url", "") ?: ""
        set(v) = sp.edit().putString("last_url", v).apply()

    companion object {
        const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
